# Time Series Forecasting
# Monthly Sales of French Champagne - Perrin Freres
The goal of this project is to forecast the number of monthly sales of champagne for the Perrin Freres label brand.
The dataset has 10 years monthly sales of Champagne with 105 observations.

Dataset : https://datamarket.com/data/set/22r5/perrin-freres-monthly-champagne-sales-millions-64-72#!ds=22r5&display=line
